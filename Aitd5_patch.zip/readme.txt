================================================================================================================================================================
Initial Release + Update 1 [27 September 2020].
================================================================================================================================================================
- Disabled various Anti-Debug features;
- Applied 64 bit compilation flags (>2 Gigs ram usage/DEP/Terminal Server Aware);
- Improved DirectX Usage/Multithreading Support;
- Restored the 'Game.INI' (A global config file for the game engine);
[Including various settings such as fps limit, shadows size, resolution, fullscreen/windowed mode switch etc].
================================================================================================================================================================
PS. My currently patched executable is now using its own config file (conf.ini) with the same purpose so it doesn't conflict with unpatched 'Alone.exe' anymore.
Don't rename both exe and config files please. Set all settings wisely. If you can't run the game - use the default settings.
================================================================================================================================================================
IMPORTANT INFORMATION
================================================================================================================================================================
By using one of my projects you're accepting the "AS IS" policy.
Author (unknownproject) is an oldskool grayhat hacker and a reverse engineer. !!!Not a modder!!!
Author is not responsible for your own lack of knowledge/hardware damages or anything else that happens with your system(s).
Each project includes various txt files. They're available as individual downloads just because I want. 
If you don't want to read them - don't even try to ask help.
Author is making these things as his own hobby and spending as much time as possible so your requests and complaining just make no sense for him.
Every part of my patch and the differences between original and my files (including my own code) are free to use.
You are not allowed to distribute/dissassemble my projects without linking to original resources and/or mentioning me.
[Nukers are lamers].
================================================================================================================================================================
Contacts:
Email - nknwn.project@gmail.com
Steam - http://steamcommunity.com/profiles/76561198017988277
YouTube - https://www.youtube.com/channel/UCCjgivnEXTz7vLE4n894Wsg
================================================================================================================================================================
Donate:
BitCoin - 1La9snD8Kao9WNexqH1j5t6PbeAtNtXTio
If you wish to use alternative ways - just contact me.
================================================================================================================================================================
(c) Unknownproject. Made in Russia. Copyright material used under fair use for research and improvement purposes.
================================================================================================================================================================